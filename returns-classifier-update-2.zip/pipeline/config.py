"""Models and prices in one place, so changing a model is a one-line edit."""

SMALL_MODEL = "google/gemini-3.5-flash-lite"     # reads every row: triage and detail
STRONG_MODEL = "anthropic/claude-sonnet-5.5"     # reads only the rows the small model is unsure of

# US dollars per million tokens (input, output), from openrouter.ai on 2 October 2026.
# Update these when you change a model or when prices move.
PRICES = {
    "google/gemini-3.5-flash-lite": (0.15, 1.25),
    "google/gemini-3.8-flash": (0.375, 1.875),
    "anthropic/claude-sonnet-5.5": (2.00, 10.00),
}

WEEKLY_OTHER_ROWS = 6500     # 48,000 orders x 31% returns x 44% "Other", from the brief
MIN_ROWS_TO_RANK = 5         # groups smaller than this are too thin to act on


def cost_usd(model: str, tokens_in: int, tokens_out: int):
    """Dollars for a model's token use, or None when the model has no price listed above."""
    if model not in PRICES:
        return None
    price_in, price_out = PRICES[model]
    return tokens_in / 1e6 * price_in + tokens_out / 1e6 * price_out
